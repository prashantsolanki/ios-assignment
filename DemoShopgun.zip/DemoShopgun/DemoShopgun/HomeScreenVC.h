//
//  HomeScreenVC.h
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeScreenVC : UIViewController
{
    
}
@property (nonatomic,strong) IBOutlet UILabel *lblSessionKey;
@end
