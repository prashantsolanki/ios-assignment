//
//  GlobalHeader.h
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.

/*
 Response Dictionary: {
 posts =     (
 {
 error = "No Data Found";
 }
 );
 }
 
 Response Dictionary: {
 posts =     (
 {
 post =             {
 email = "test1@test.com";
 id = 3;
 password = "test@123";
 session = f3va4z9s97;
 };
 }
 );
 }
 */


#ifndef GlobalHeader_h
#define GlobalHeader_h


#define URL_LOGIN @"http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?"
//http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?function=getLoginDetail&email=test1@test.com&password=test@123&num=10&format=json

#define URL_REGISTER @"http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?"
//http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?function=setLoginDetail&email=test1@test.com&password=test@123&num=10&format=json

#define URL_FORGET_PASSWORD @"http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?"
//http://bestindianrecipes.in.cp-19.webhostbox.net/webservice/web-service.php?function=forgetPassword&email=test1@test.com&num=10&format=json



#define KEY_WEB_TITLE       @"title"
#define KEY_WEB_DESCRIPTION @"message"

#define KEY_DEFAULT_EMAIL @"defaultEmail"
#define KEY_DEFAULT_PSWD @"defaultPswd"

#define KEY_USERID @"userID"
#define Key_SESSION @"SessionKey"

#define helvetica_nueue @"Helvetica Neue"

#endif /* GlobalHeader_h */
