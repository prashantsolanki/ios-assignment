//
//  AppDelegate.h
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "AFNetworkReachabilityManager.h"

@class ViewController;
@interface AppDelegate : NSObject <UIApplicationDelegate>
{
    
}
@property (strong, nonatomic) IBOutlet UIWindow *window;
@property (nonatomic,strong) IBOutlet ViewController *viewController;
@property (nonatomic, strong) UINavigationController *navController;

@end

