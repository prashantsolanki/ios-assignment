//
//  ViewController.h
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignupScreenVC.h"
#import "HomeScreenVC.h"

@class SignupScreenVC;
@class HomeScreenVC;

@interface ViewController : UIViewController<UITextFieldDelegate,UIGestureRecognizerDelegate>
{
    
}
@property (nonatomic,strong) IBOutlet UIView *viewCustom,*viewfrgtPswd,*viewsubfrgtPswd;
@property (nonatomic,strong) IBOutlet UIButton *btnLogin,*btnCancel,*btnSignup,*btnFrgtPswd;
@property (nonatomic,strong) IBOutlet UITextField *txtUname,*txtPswd,*txtEmail;
@property (nonatomic,strong) SignupScreenVC *signVC;
@property (nonatomic,strong) HomeScreenVC *HomeVC;
@end

