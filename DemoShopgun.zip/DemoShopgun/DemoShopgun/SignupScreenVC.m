//
//  SignupScreenVC.m
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import "SignupScreenVC.h"
#import "GlobalHeader.h"
#import "AFNetworkReachabilityManager.h"
#import "AFNetworking.h"

@interface SignupScreenVC ()

@end

@implementation SignupScreenVC

@synthesize txtEmail,txtPswd,txtRePswd,selfSubView,btnReg,networkReachability,btnCancel;

- (void)viewDidLoad {
    [super viewDidLoad];
    MyDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    dateformatter=[[NSDateFormatter alloc]init];
    
    screenRect = [[UIScreen mainScreen] bounds];
    screenWidth = screenRect.size.width;
    
    selfSubView.layer.cornerRadius = 6.0;
    btnReg.layer.cornerRadius = 4.0;
    btnCancel.layer.cornerRadius = 4.0;
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)prefersStatusBarHidden {
    
    return YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
   
    
}

-(IBAction)goBack:(id)sender
{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)cancelView:(id)sender
{
    
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    
}

-(IBAction)RegisterUser:(id)sender
{
    /*
    networkReachability = [AFNetworkReachabilityManager reachabilityForInternetConnection];
    
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];*/
    /*
    networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];*/
    
    NSString *strPswd,*strcnfmPswd,*strEmail;
    
    strEmail = txtEmail.text;
    strPswd = txtPswd.text;
    strcnfmPswd = txtRePswd.text;
    
    if ([strEmail length] == 0 || strEmail == nil || [strEmail isEqual:@""] == TRUE)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Empty Email Field",nil) message:NSLocalizedString(@"Please enter email address",nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    if ([strPswd length] < 6)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Invalid Password",nil) message:NSLocalizedString(@"Password should have atleast 6 character", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    if ([strPswd isEqualToString:@""] || ([strcnfmPswd isEqualToString:@""]))
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Empty Password Field",nil) message:NSLocalizedString(@"Please enter password", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    if ([strPswd isEqualToString:strcnfmPswd])
    {
        NSLog(@"Password match");
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Password Mismatch",nil) message:NSLocalizedString(@"Password & Re-Type Password should be same",nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    if (![self validEmail:[txtEmail text]])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Invalid Email", nil)  message:NSLocalizedString(@"Please enter a valid email address", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        txtEmail.text=@"";
        [txtEmail becomeFirstResponder];
    }
    else{
        NSLog(@"Its valid email address & Password");
        if ([[AFNetworkReachabilityManager sharedManager] isReachable])
        {
            [self registerUserCall];
            [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Network Error", nil)  message:NSLocalizedString(@"You are not connected to internet", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            return;
        }
    }
    
}
-(void)registerUserCall
{
    [dateformatter setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    
    NSString *registerTimestamp =[dateformatter stringFromDate:[NSDate date]];
    NSLog(@"%@",registerTimestamp);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    
    NSString *finalURL = [NSString stringWithFormat:@"%@function=setLoginDetail&email=%@&password=%@&num=10&format=json",URL_REGISTER,txtEmail.text,txtPswd.text];
    
    NSDictionary *params = @{@"email":txtEmail.text,@"password":txtPswd.text};
    
    NSLog(@"Parsed URL : %@",finalURL);
    [manager GET:finalURL parameters:nil success:^void(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSLog(@"Register done");
         NSLog(@"ResponseString: %@", operation.responseString);
         NSError *errParse = nil;
         NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:[operation.responseString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&errParse];
         
         NSLog(@"Response Dictionary: %@", responseDictionary);
         NSArray *arrData = (NSArray *)[responseDictionary objectForKey:@"posts"];
         NSDictionary *subDict1 = [arrData objectAtIndex:0];
         
         NSString *strSuccess = [subDict1 objectForKey:@"error"];
         if ([strSuccess isEqualToString:@"insert successful"])
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Success", nil)  message:NSLocalizedString(@"Registration done successful", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
             [alert show];
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Failed", nil)  message:NSLocalizedString(@"Registration process failed", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
             [alert show];
         }
         /*
          {"posts":[{"error":"insert successful"}]}
          */
     }failure:^ void(AFHTTPRequestOperation * operation, NSError *error) {
         self.title = @"Error Received.";
         NSLog(@"ResponseString: %@", operation.responseString);
         NSLog(@"Error: %@", error);
     }];
}

#pragma mark -
#pragma mark Touches methods

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch= [touches anyObject];
    if ([touch view] == selfSubView|| [touch view] == self.view)
    {
        
        [self.view endEditing:YES];
    }
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    [self touchesBegan:touches withEvent:event];
}


-(BOOL) validEmail:(NSString*) emailString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailString];
}

@end
