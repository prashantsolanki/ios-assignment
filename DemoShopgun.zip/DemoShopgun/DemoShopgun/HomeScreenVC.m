//
//  HomeScreenVC.m
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import "HomeScreenVC.h"
#import "GlobalHeader.h"
#import "AFNetworkReachabilityManager.h"
#import "AFNetworking.h"

@interface HomeScreenVC ()

@end

@implementation HomeScreenVC
@synthesize lblSessionKey;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (BOOL)prefersStatusBarHidden {
    
    return YES;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
    NSUserDefaults *defaultData = [NSUserDefaults standardUserDefaults];
    lblSessionKey.text = [defaultData objectForKey:Key_SESSION];
    
}
-(IBAction)gotoBack:(id)sender
{
    [[self navigationController]popViewControllerAnimated:YES];
}

-(IBAction)logoutUser:(id)sender
{
    [[self navigationController]popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
