//
//  ViewController.m
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "GlobalHeader.h"
#import "AFNetworkReachabilityManager.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize viewCustom,txtPswd,txtUname,btnLogin,btnCancel,btnSignup;
@synthesize viewfrgtPswd,viewsubfrgtPswd,txtEmail,signVC,HomeVC;

- (void)viewDidLoad {
    [super viewDidLoad];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    
    viewCustom.layer.cornerRadius = 6.0;
    btnLogin.layer.cornerRadius = 4.0;
    btnCancel.layer.cornerRadius = 4.0;
    viewsubfrgtPswd.layer.cornerRadius = 6.0;
    
    UIBarButtonItem *btnLoginItem = [[UIBarButtonItem alloc] initWithTitle:@"LOGIN" style:UIBarButtonItemStylePlain target:self action:@selector(openLogin:)];
    
    self.navigationItem.rightBarButtonItem = btnLoginItem;
    
    self.title =@"SHOPGUN";
    [self.viewCustom setHidden:YES];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)openLogin:(id)sender
{
    [self.viewCustom setHidden:NO];
}
-(IBAction)loginUser:(id)sender
{
    if(![txtUname.text isEqualToString:@""])
    {
        NSLog(@"Email Done");
        
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Login Failed", nil)  message:NSLocalizedString(@"Please enter email address",nil)  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    
    if(![txtPswd.text isEqualToString:@""])
    {
        NSLog(@"password done");
    }
    else{
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Login Failed", nil)  message:NSLocalizedString(@"Please enter Password", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    
    if (![self validEmail:[txtUname text]])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Invalid Email", nil)  message:NSLocalizedString(@"Please enter a valid email address", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        txtUname.text=@"";
        [txtUname becomeFirstResponder];
        
    }
    else
    {
        if ([[AFNetworkReachabilityManager sharedManager] isReachable]) {
            NSLog(@"IS REACHABILE");
            NSLog(@"Its valid email address");
            
            NSUserDefaults *defaultCredential = [NSUserDefaults standardUserDefaults];
            
            
            
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            manager.requestSerializer = [AFHTTPRequestSerializer serializer];
            
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            
            NSString *finalURL = [NSString stringWithFormat:@"%@function=getLoginDetail&email=%@&password=%@&num=10&format=json",URL_LOGIN,txtUname.text,txtPswd.text];
            NSLog(@"Parsed URL : %@",finalURL);
            
            [manager GET:finalURL parameters:nil success:^void(AFHTTPRequestOperation *operation, id responseObject)
             {
                 NSLog(@"Login done");
                 NSLog(@"ResponseString: %@", operation.responseString);
                 
                 
                 NSError *errParse = nil;
                 NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:[operation.responseString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&errParse];
                 
                 
                 NSArray *arrData = (NSArray *)[responseDictionary objectForKey:@"posts"];
                 
                 
                 NSDictionary *subDict1 = [arrData objectAtIndex:0];
                 
                 NSDictionary *subDict2 = [subDict1 objectForKey:@"post"];
                 NSLog(@"Response subDict2: %@",subDict2);
                 
                 NSLog(@"Response Data: %@",subDict1);
                 
                 NSString *strID = [subDict2 objectForKey:@"id"];
                 NSString *strEmail = [subDict2 objectForKey:@"email"];
                 NSString *strSession = [subDict2 objectForKey:@"session"];
                 
                 [defaultCredential setObject:strSession forKey:Key_SESSION];
                 
                 NSString *strError = [NSString stringWithFormat:@"%@",[subDict1 objectForKey:@"error"]];
                 NSLog(@"FetchData: %@ %@ %@", strID,strEmail,strSession);
                 NSLog(@"FetchData error: %@", strError);
                 
                 if ([strError isEqualToString:@"No Data Found"])
                 {
                     txtUname.text = @"";
                     txtPswd.text = @"";
                     [txtUname becomeFirstResponder];
                     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Login Failed", nil)  message:NSLocalizedString(@"Invalid Username/Password", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                     [alert show];
                     return;
                 }
                 if (![strEmail isEqualToString:@""])
                 {
                     if (HomeVC == nil)
                     {
                         HomeScreenVC *hv = [[HomeScreenVC alloc]initWithNibName:@"HomeScreenVC" bundle:[NSBundle mainBundle]];
                         self.HomeVC = hv;
                     }
                     
                     [[self navigationController]pushViewController:HomeVC animated:YES];
                 }
                 
                 [defaultCredential synchronize];
                 
             }failure:^ void(AFHTTPRequestOperation * operation, NSError *error) {
                 self.title = @"Error Received.";
                 NSLog(@"ResponseString: %@", operation.responseString);
                 NSLog(@"Error: %@", error);
             }];
        }
        else
        {
            NSLog(@"NOT REACHABLE");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Network Error", nil)  message:NSLocalizedString(@"You are not connected to internet", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            return;
        }
        
    }
    
        
      
}

-(IBAction)cancelLogin:(id)sender
{
    txtUname.text = @"";
    txtPswd.text = @"";
    [txtUname resignFirstResponder];
    [txtPswd resignFirstResponder];
    
    [self.viewCustom setHidden:YES];
}
- (BOOL)prefersStatusBarHidden {
    
    return YES;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
    txtUname.text = @"";
    txtPswd.text = @"";
    
}

-(IBAction)openSignupScreen:(id)sender
{
    signVC = [[SignupScreenVC alloc]initWithNibName:@"SignupScreenVC" bundle:[NSBundle mainBundle]];
    [self presentViewController:signVC animated:YES completion:nil];
}

-(IBAction)openForgetPasswordScreen:(id)sender
{
    [self cancelLogin:nil];
    [self.view addSubview:viewfrgtPswd];
}

-(IBAction)closePasswordScreen:(id)sender
{
    [self.viewfrgtPswd removeFromSuperview];
    [self openLogin:nil];
}

-(IBAction)recoverPassword:(id)sender
{
    if(![txtEmail.text isEqualToString:@""])
    {
        NSLog(@"Email Done");
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Password Recover Failed", nil)  message:NSLocalizedString(@"Please enter email address",nil)  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    if (![self validEmail:[txtEmail text]])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Invalid Email", nil)  message:NSLocalizedString(@"Please enter a valid email address", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        txtEmail.text=@"";
        [txtEmail becomeFirstResponder];
    }
    else
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];

    
    NSString *finalURL = [NSString stringWithFormat:@"%@function=forgetPassword&email=%@&num=10&format=json",URL_FORGET_PASSWORD,txtEmail.text];
    NSLog(@"Parsed URL : %@",finalURL);
    
    [manager GET:finalURL parameters:nil success:^void(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSLog(@"Login done");
         NSLog(@"ResponseString: %@", operation.responseString);
         
         
         NSError *errParse = nil;
         NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:[operation.responseString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&errParse];
         
         NSLog(@"Response Dictionary: %@", responseDictionary);
         NSArray *arrData = (NSArray *)[responseDictionary objectForKey:@"posts"];
         NSDictionary *subDict1 = [arrData objectAtIndex:0];
         
         NSDictionary *subDict2 = [subDict1 objectForKey:@"post"];

         
         NSString *strID = [subDict2 objectForKey:@"id"];
         NSString *strEmail = [subDict2 objectForKey:@"email"];
         NSString *strPassword = [subDict2 objectForKey:@"password"];
         
         NSString *strError = [subDict1 objectForKey:@"error"];
         NSLog(@"Recover Data: %@ %@ %@", strID,strEmail,strPassword);
         NSLog(@"Recovery Error = %@",strError);
         
         if ([strError isEqualToString:@"No Data Found"])
         {
             txtEmail.text = @"";
             [txtEmail becomeFirstResponder];
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Password Recover Failed", nil)  message:NSLocalizedString(@"No registered email found", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
             [alert show];
             return;
         }
         if (![strEmail isEqualToString:@""])
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Password Recover Done", nil)  message:[NSString stringWithFormat:@"Password = %@",strPassword] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
             [alert show];
         }
         

     }failure:^ void(AFHTTPRequestOperation * operation, NSError *error) {
         self.title = @"Error Received.";
         NSLog(@"ResponseString: %@", operation.responseString);
         NSLog(@"Error: %@", error);
     }];
}
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL) validEmail:(NSString*) emailString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailString];
}


#pragma mark -
#pragma mark Touches methods

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch= [touches anyObject];
    if ([touch view] == self.view)
    {
        [txtUname resignFirstResponder];
        [txtPswd resignFirstResponder];
        
    }
}
@end
