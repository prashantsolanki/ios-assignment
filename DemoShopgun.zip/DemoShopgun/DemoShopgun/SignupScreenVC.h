//
//  SignupScreenVC.h
//  DemoShopgun
//
//  Created by Prashant on 13/05/16.
//  Copyright © 2016 Prashant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworkReachabilityManager.h"
#import "AppDelegate.h"
//#import "Reachability.h"

@class AppDelegate;
@interface SignupScreenVC : UIViewController<UITextFieldDelegate,UIGestureRecognizerDelegate>
{
    CGRect screenRect;
    CGFloat screenWidth,screenHeight;
    AFNetworkReachabilityManager *networkReachability;
  //  Reachability *networkReachability;
    AppDelegate *MyDelegate;
    NSDateFormatter *dateformatter;
}
@property (nonatomic,strong) AFNetworkReachabilityManager *networkReachability;
//@property (nonatomic,strong) Reachability *networkReachability;
@property(nonatomic,strong) IBOutlet UITextField *txtEmail,*txtPswd,*txtRePswd;
@property (nonatomic,strong) IBOutlet UIView *selfSubView;
@property (nonatomic,strong) IBOutlet UIButton *btnReg,*btnCancel;

-(BOOL) validEmail:(NSString*) emailString;
@end
